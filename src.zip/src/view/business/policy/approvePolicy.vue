<template>
  <div>
    审核策略
  </div>
</template>
<script>

  export default {
    name: 'approvePolicy',
    data() {
      return {
      }
    },
    components: {},
    activated() {
    },
    mounted() {
    },
    methods: {
    },
    computed: {
    }
  }
</script>
