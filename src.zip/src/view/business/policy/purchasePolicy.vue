<template>
  <div>
    采购策略
  </div>
</template>
<script>

  export default {
    name: 'purchasePolicy',
    data() {
      return {
      }
    },
    components: {},
    activated() {
    },
    mounted() {
    },
    methods: {
    },
    computed: {
    }
  }
</script>
