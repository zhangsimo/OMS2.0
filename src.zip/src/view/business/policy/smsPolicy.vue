<template>
  <div>
    短信策略
  </div>
</template>
<script>

  export default {
    name: 'smsPolicy',
    data() {
      return {
      }
    },
    components: {},
    activated() {
    },
    mounted() {
    },
    methods: {
    },
    computed: {
    }
  }
</script>
