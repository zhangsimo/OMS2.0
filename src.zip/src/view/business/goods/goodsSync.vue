<template>
  <div>
    商品同步
  </div>
</template>
<script>

  export default {
    name: 'goodsSync',
    data() {
      return {
      }
    },
    components: {},
    activated() {
    },
    mounted() {
    },
    methods: {
    },
    computed: {
    }
  }
</script>
