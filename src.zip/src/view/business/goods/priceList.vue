<template>
  <div>
    价格管理
  </div>
</template>
<script>

  export default {
    name: 'priceList',
    data() {
      return {
      }
    },
    components: {},
    activated() {
    },
    mounted() {
    },
    methods: {
    },
    computed: {
    }
  }
</script>
