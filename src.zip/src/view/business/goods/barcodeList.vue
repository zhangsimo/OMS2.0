<template>
  <div>
    条码管理
  </div>
</template>
<script>

  export default {
    name: 'barcodeList',
    data() {
      return {
      }
    },
    components: {},
    activated() {
    },
    mounted() {
    },
    methods: {
    },
    computed: {
    }
  }
</script>
