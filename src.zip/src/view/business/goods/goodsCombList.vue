<template>
  <div>
    组合商品
  </div>
</template>
<script>

  export default {
    name: 'goodsCombList',
    data() {
      return {
      }
    },
    components: {},
    activated() {
    },
    mounted() {
    },
    methods: {
    },
    computed: {
    }
  }
</script>
