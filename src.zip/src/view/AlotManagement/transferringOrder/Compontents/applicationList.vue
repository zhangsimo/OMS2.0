<template>
    <div>

    </div>
</template>

<script>
    export default {
        name: "applicationList"
    }
</script>

<style scoped>

</style>
