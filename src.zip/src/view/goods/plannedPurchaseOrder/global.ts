export enum orderState {
    '作废' = -1, '草稿', '审批中', '待收货', '部分入库', '全部入库', '退回'
}