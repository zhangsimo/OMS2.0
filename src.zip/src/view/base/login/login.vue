
<template>
  <GpartLoginPage @on-commit="commit">{{loginPageTitle}}</GpartLoginPage>
</template>

<script>
  import {mapActions} from 'vuex'
  import GpartLoginPage from '_c/login'
  import systemUri from "_conf/systemUri"
  import { loginSystem } from "_api/base/user"
  export default {
    data () {
      return {
        loginPageTitle: '欢迎使用极配订单管理系统'
      }
    },
    components: {GpartLoginPage},
    methods: {
      ...mapActions([
        'handleLogin',
        'getUserInfo'
      ]),
      commit({username, password, scope, errCallback}) {
        switch(scope) {
            case "wms":
              // systemUri
              loginSystem({ uri: systemUri.wmsTokenApi, username, password }).then(res => {
                if(res.code == 0) {
                  // systemUri.wms = 'http://192.168.30.129:8088'
                  const uri = systemUri.wms + encodeURI(`?username=${username}&password=${password}`);
                  location.href = uri
                }
              })
              break;
            case "oms":
            default:
              this.handleLogin({username, password}).then(res => {
                localStorage.setItem('username', username)
                this.getUserInfo(username).then(res => {
                    let data = {}
                        data.tenantId = res.tenantId
                        data.shopId = res.shopId
                        data.shopkeeper = res.shopkeeper
                        localStorage.setItem('oms2-userList' , JSON.stringify(data))
                    this.$router.push({
                    name: 'home'
                  })
                })
              }).catch(err => {
                errCallback && errCallback()
              })
              break;
          }
      }
    }
  }
</script>
