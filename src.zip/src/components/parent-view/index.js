import ParentView from './parent-view.vue'
export default ParentView
