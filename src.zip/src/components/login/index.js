import GpartLoginPage from './login'
export default GpartLoginPage