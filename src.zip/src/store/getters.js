const getters = {
  oosmask: state => state.common.status
}
export default getters
